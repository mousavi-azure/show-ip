<?php
// Local dev router for `php -S`, mirroring .htaccess RewriteRules so clean
// URLs behave the same as they will on Apache. Not used in production.
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rawurldecode($uri);

// 127.0.0.1 is a reserved IP the real API rejects — fake a public IP for local testing.
// Override via ?testip=1.2.3.4
$_SERVER['HTTP_X_FORWARDED_FOR'] = $_GET['testip'] ?? '5.74.245.38';

$root = dirname(__DIR__);
if ($uri !== '/' && file_exists($root . $uri) && !is_dir($root . $uri)) {
    return false; // serve static file as-is
}

$map = [
    '#^/faq/?$#' => ['faq.php', []],
    '#^/blog/?$#' => ['blog.php', []],
    '#^/blog/([a-z0-9-]+)/?$#' => ['blog.php', ['slug' => '$1']],
    '#^/feed/?$#' => ['rss.php', []],
    '#^/en/feed/?$#' => ['rss.php', ['lang' => 'en']],
    '#^/en/faq/?$#' => ['faq.php', ['lang' => 'en']],
    '#^/en/blog/?$#' => ['blog.php', ['lang' => 'en']],
    '#^/en/blog/([a-z0-9-]+)/?$#' => ['blog.php', ['lang' => 'en', 'slug' => '$1']],
    '#^/en/?$#' => ['index.php', ['lang' => 'en']],
    '#^/ip/?$#' => ['index.php', ['format' => 'text']],
    '#^/json/?$#' => ['index.php', ['format' => 'json']],
];

foreach ($map as $pattern => [$script, $params]) {
    if (preg_match($pattern, $uri, $m)) {
        foreach ($params as $k => $v) {
            $_GET[$k] = $v === '$1' ? $m[1] : $v;
        }
        chdir($root);
        require $root . '/' . $script;
        return true;
    }
}

if ($uri === '/' || $uri === '') {
    chdir($root);
    require $root . '/index.php';
    return true;
}

return false;
